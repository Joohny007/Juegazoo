#include "Bloque.h"

//Bloque::Player(int x)
//{
//	//this->model.setIdentity();
//	this->mesh = NULL;
//	this->shader = NULL;
//	this->texture = NULL;
//
//}