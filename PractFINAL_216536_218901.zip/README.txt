Joan Fernandez Ardanuy  216536  joan.fernandez01@estudiant.upf.edu
Joan Gonzalez Perez  218901 joan.gonzalez03@estudiant.upf.edu